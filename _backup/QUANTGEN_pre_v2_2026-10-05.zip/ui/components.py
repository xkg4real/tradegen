"""Shared presentation atoms for the cockpit.

Kept in one place because the three pages must agree on what "ready" looks like.
A skill that is blocked on a key and a workflow that is blocked on a key should
be the same colour, the same word, and the same shape, or the operator has to
re-learn the interface on every tab.
"""
from __future__ import annotations

from typing import Callable, Optional

import flet as ft

from core.skills.readiness import State
from core.theme import RADII, active

# One vocabulary for readiness, used by every surface.
STATE_STYLE: dict[State, tuple[str, str]] = {
    State.READY:       ("Ready", "success"),
    State.NEEDS_INPUT: ("Needs input", "accent"),
    State.MISSING_KEY: ("Key required", "error"),
    State.DOC_ONLY:    ("Reference only", "muted"),
}

RUN_STATUS_STYLE: dict[str, tuple[str, str]] = {
    "ok":        ("Succeeded", "success"),
    "failed":    ("Failed", "error"),
    "timeout":   ("Timed out", "error"),
    "cancelled": ("Cancelled", "muted"),
    "error":     ("Could not start", "error"),
    "running":   ("Running", "accent"),
}


def _colour(token: str) -> str:
    return getattr(active(), token)


def colour_for(token: str) -> str:
    """Resolve a palette token to a colour. Public so pages can tint text and
    icons with the same tokens the chips use, instead of picking their own."""
    return _colour(token)


def chip(text: str, token: str = "muted", *, tooltip: str = "") -> ft.Container:
    """Small status pill. Carries a text label, never colour alone."""
    pal = active()
    return ft.Container(
        content=ft.Text(text, size=11, color=_colour(token), weight=ft.FontWeight.W_500),
        padding=ft.Padding(8, 3, 8, 3),
        bgcolor=pal.surface_2,
        border=ft.Border.all(1, _colour(token)),
        border_radius=RADII["pill"],
        tooltip=tooltip or None,
    )


def readiness_chip(state: State, *, tooltip: str = "") -> ft.Container:
    label, token = STATE_STYLE[state]
    return chip(label, token, tooltip=tooltip)


def run_status_chip(status: str) -> ft.Container:
    label, token = RUN_STATUS_STYLE.get(status, (status or "unknown", "muted"))
    return chip(label, token)


def section(title: str, *, subtitle: str = "") -> ft.Column:
    pal = active()
    rows = [ft.Text(title, size=26, weight=ft.FontWeight.BOLD, color=pal.text)]
    if subtitle:
        rows.append(ft.Text(subtitle, size=13, color=pal.muted))
    return ft.Column(rows, spacing=4)


def card(content: ft.Control, *, on_click: Optional[Callable] = None,
         col: Optional[dict] = None, tooltip: str = "") -> ft.Container:
    pal = active()
    return ft.Container(
        content=content,
        padding=16,
        bgcolor=pal.surface,
        border=ft.Border.all(1, pal.border),
        border_radius=RADII["lg"],
        on_click=on_click,
        ink=on_click is not None,
        tooltip=tooltip or None,
        col=col,
    )


def notice(text: str, token: str = "accent", *, icon: str = ft.Icons.INFO_OUTLINE,
           action: Optional[ft.Control] = None) -> ft.Container:
    """Banner for a state the operator must act on. Loud enough to be read."""
    pal = active()
    row = [
        ft.Icon(icon, size=18, color=_colour(token)),
        ft.Text(text, size=13, color=pal.text, expand=True, selectable=True),
    ]
    if action is not None:
        row.append(action)
    return ft.Container(
        content=ft.Row(row, spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER),
        padding=14,
        bgcolor=pal.surface_2,
        border=ft.Border.all(1, _colour(token)),
        border_radius=RADII["md"],
    )


def empty_state(title: str, detail: str, *, icon: str = ft.Icons.INBOX_OUTLINED,
                action: Optional[ft.Control] = None) -> ft.Container:
    """An empty screen must say what is missing and what to do about it."""
    pal = active()
    items = [
        ft.Icon(icon, size=40, color=pal.muted),
        ft.Text(title, size=16, weight=ft.FontWeight.W_600, color=pal.text,
                text_align=ft.TextAlign.CENTER),
        ft.Text(detail, size=13, color=pal.muted, text_align=ft.TextAlign.CENTER),
    ]
    if action is not None:
        items.append(ft.Container(action, padding=ft.Padding(0, 8, 0, 0)))
    return ft.Container(
        content=ft.Column(items, spacing=10,
                          horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        alignment=ft.Alignment.CENTER,
        padding=48,
        expand=True,
    )


def key_value(label: str, value: str, *, width: int = 132) -> ft.Row:
    pal = active()
    return ft.Row(
        [ft.Text(label, size=12, color=pal.muted, width=width),
         ft.Text(value or "—", size=12, color=pal.text, expand=True, selectable=True)],
        spacing=8, vertical_alignment=ft.CrossAxisAlignment.START,
    )


def mono(text: str, *, size: int = 11) -> ft.Text:
    return ft.Text(text, size=size, color=active().text, selectable=True,
                   font_family="Consolas, monospace")


def stat(label: str, value: str, *, token: str = "text", tooltip: str = "") -> ft.Container:
    """Metric tile: small muted label over a bold value. Every result strip in
    the app is a row of these, so they must look identical across pages."""
    pal = active()
    return ft.Container(
        ft.Column([
            ft.Text(label, size=10, color=pal.muted),
            ft.Text(value, size=16, weight=ft.FontWeight.W_600,
                    color=getattr(pal, token, pal.text)),
        ], spacing=2),
        padding=ft.Padding(14, 10, 14, 10), bgcolor=pal.surface_2,
        border=ft.Border.all(1, pal.border), border_radius=RADII["md"],
        tooltip=tooltip or None,
    )
