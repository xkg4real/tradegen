# QUANTGEN

The upgraded, personal-use successor to NEXTGEN. Same body — the rule engine,
simulated order book, KRX data layer, and skill cockpit all survive intact —
with the one organ the client build was contractually forbidden from having:
**an opinion**. QUANTGEN computes analysis, ranks outcomes, and recommends.

Version 2 widens the desk. The equity surfaces (Quant Lab, Portfolio, Signals)
stay as they were; five FICC surfaces now sit first in the rail, built for the
world the OTM FICC & Quant curriculum lives in — rates and FX derivatives,
treasuries and credit, pricing, structuring, and the weekly rates/FX strategy
read.

Version 3 widens the asset coverage and adds the gate that decides what is
offered. Four surfaces — **Derivatives, ETF, Crypto, Strategy Lab** — sit on
the KIS asset domains the stock-account key already quotes (ETF NAV, KOSPI 200
futures and options, KTB and USD futures, KRW benchmark yields, overseas
prices) and on keyless Upbit / Binance / CoinGecko data. Every strategy and
distributional model was validated on real history by one pre-registered
gate; what failed is shown as a refusal, not hidden. See
[The expansion surfaces](#the-expansion-surfaces-version-3).

This is a personal instrument, not a client deliverable. It is not for
commercial distribution, and every trading decision it informs remains the
operator's own.

---

## The FICC surfaces

### Macro — the sheet, the regime, the reports

Eighteen cross-asset indicators (2y/10y/30y, 2s10s, 10y real and breakeven,
SOFR and Fed funds, IG and HY OAS, the broad dollar, EUR/JPY/KRW fixings, VIX,
WTI, the 10y note future, gold), each with 1d/1w/1m/3m changes, a one-year
z-score and percentile. A regime read on top: curve (bull/bear steepener or
flattener, parallel), risk (VIX and HY OAS z-scores), dollar, inflation, real
rates. Two buttons write the club's homework: **Daily market commentary** and
**Weekly rates/FX strategy** — a local narrative immediately, and the Claude
deep read with a strategist's report format when a key is set.

### Rates — curve, swaps, swaptions, short-rate simulation

| Tool | What it does |
|---|---|
| **Yield curve** | Bootstraps the Treasury par curve to continuously-compounded zeros, fits Nelson-Siegel or Svensson, reports 2s10s / 5s30s / 3m10y / the 2-5-10 fly / 1y1y / 2y1y / 5y5y, names the shape and the 20-session regime, and runs PCA on daily curve changes (level, slope, curvature with explained variance) |
| **Swap pricer** | Par rate, PV, DV01 and key-rate DV01 for spot or forward-starting swaps (`10y`, `5y5y`), carry and roll-down, the forward-rate table |
| **Swaption / cap-floor** | Black-76 (lognormal) and Bachelier (normal) with premium in currency and bp of notional, delta, gamma, vega, theta, and the implied vol in the other model; caps and floors as caplet strips |
| **Rate simulation** | Vasicek, CIR and Hull-White calibrated on SOFR (OLS on daily changes; HW's θ(t) fitted to the live curve), seeded paths, the terminal distribution, and the horizon P&L distribution of a bond or swap revalued on each path's model curve |

### Bonds — price, risk, scenarios, hedge

Price ↔ yield, Macaulay and modified duration, convexity, DV01, key-rate DV01
across the nine key tenors, z-spread to the curve, carry and roll-down with the
breakeven move. Nine curve scenarios revalue the bond in full (parallel ±25/±100,
bear/bull steepeners and flatteners, the 2-5-10 fly) so convexity shows up as
the asymmetry it is. A futures hedge ratio from position DV01, CTD DV01 and the
conversion factor.

### FX — forwards, options, smiles, carry

| Tool | What it does |
|---|---|
| **Spot, forward & carry** | Covered-interest-parity forwards and points from the two funding rates (pulled live: SOFR, ECB deposit rate, SONIA, and the OECD monthly series for the rest), carry for the position, and the implied cross-currency basis if a market forward is supplied |
| **Option & smile** | Garman-Kohlhagen with spot and forward delta, gamma, vega, theta, both rhos, vanna and volga; strikes from deltas; a smile built from ATM / 25Δ risk reversal / 25Δ butterfly quotes and fitted with Hagan's SABR |
| **Carry basket** | G10 + KRW versus USD: carry, realised vol, carry-to-vol and momentum per currency, and a long-top-3 / short-bottom-3 backtest that ranks on rates known at *t* and earns from *t+1* |

### Structuring — the pitchbook, with the hedge

Four products decomposed into legs and priced off the same curve and option
engines: **principal-protected note** (zero + participation in an ATM call),
**reverse convertible** (bond + short put, coupon solved for the issue price),
**dual-currency deposit** (deposit + short FX option, enhanced yield and the
conversion strike), and **steepener note** (coupon on the 10y–2y forward
spread, priced off forwards with a loud note that it carries no convexity
adjustment). Every product reports fair value against issue price, the
distributor margin, its Greeks, a payoff chart, and a hedge sheet sized in
spot, vanillas, swaps and futures.

### Conventions the whole FICC core shares

Rates, spreads and vols are decimals in the core and percent or basis points
only in the UI. Tenors are years; `3m`, `10y`, `5y5y` all parse. Zeros are
continuously compounded, discount factor `exp(−z·t)`. Day count is ACT/365
simple. **Single-curve**: one curve projects and discounts, so a floating leg
at inception is `N·(DF(start) − DF(end))`; an OIS-discounting upgrade slots in
behind `YieldCurve` without touching a caller. DV01 is currency per basis
point for the stated notional, positive for a long bond or a payer swap that
gains from higher rates. Every random draw is seeded.

---

## The equity surfaces

### Quant Lab — Monte Carlo simulation

Names a symbol, calibrates on daily history, and draws thousands of forward
paths under one of four models:

| Model | What it assumes | When it's the right one |
|---|---|---|
| **GARCH(1,1)-t** (default) | Volatility clustering (ω, α, β fitted by L-BFGS-B maximum likelihood) with Student-t innovations; the tail is fitted as 1/ν on [0, 0.4], so the normal (1/ν = 0) is nested and the "LR t vs normal" statistic is never negative, with its 5 % line at the boundary-mixture value 2.706. The mean is the sample mean, fixed. Simulated innovations are bounded at ±`Z_BOUND` (a t draw beyond it is redrawn from the t restricted to the bound), because an unbounded t gives the price no finite mean; the bound was chosen by `docs/bounded_innovation_sweep.py`. Every fit carries its precision: 95 % Wald intervals for α, β and the persistence from the observed information (the half-life interval is the persistence one mapped through), a profile-likelihood interval for ν that reaches "normal" exactly when the LR tile is below 2.706, "SE undefined" with the reason when the information matrix fails, and a chip naming every interval that reaches a bound; the unconditional vol gets no interval because the delta method was measured to cover 42–100 % depending on persistence (`docs/B2_FIX_BULLETIN.md`) | The baseline: today's conditional vol, where it settles (unconditional), the half-life in sessions, and the tail — with every guardrail (not converged, near-integrated, ν at a bound) said out loud |
| **GBM** | Lognormal returns at the sample drift and volatility | Smooth regimes; the benchmark GARCH is tested against (LR, ΔAIC) |
| **Jump diffusion** (Merton) | Diffusion plus Poisson jumps, calibrated from the sample's >3σ days | Names with gap risk — earnings, headlines |
| **Block bootstrap** | Nothing — resamples actual return blocks | When the empirical distribution (fat tails, clustering) is the point |

Every run is seeded and reproducible. Results: percentile fan over history,
terminal distribution, horizon VaR/CVaR, probability of loss, probability of
reaching a target, and for GARCH the conditional-vol path against realised vol.

**Drift is an assumption, not a calibration.** An out-of-sample study on
17 instruments over 2005–2026 (`docs/drift_study/`) found the trailing
two-year sample mean has a correlation of −0.01 with the next year's return
and loses to a flat zero at every horizon. Every model therefore draws
zero-mean shocks and adds one of four stated drifts, shown with its
arithmetic on the result:

| Drift | μ (annualised log) | Use |
|---|---|---|
| **Risk premium** (default) | rf + ERP, minus each model's exact per-step convexity correction | The forecast view; rf is the live 3-month T-bill from FRED, ERP is your assumption (4% equity, 1% bonds/gold, 0 FX). The mean path grows at rf + ERP under every model |
| **Zero** | 0 | The stress view; nothing beats it significantly |
| **Risk-neutral** | rf, minus the same per-step correction | The pricing measure the structuring pages use; not a forecast. The discounted price is a martingale under every model, including GARCH-t |
| **Sample mean** | mean daily log return × 252 | Kept for transparency; labelled noisy (standard error ≈ σ/√2 on two years) |

The per-step correction c_t = ln E[exp(shock_t)] is ½σ² of the sample variance
for GBM (the lognormal correction), the diffusion half-variance plus the jump
compensator for the jump model, the increments of the empirical block log-MGF
for the bootstrap, and c(σ_t) from each path's own conditional variance for
GARCH-t, tabulated once per (ν, bound). The result reports the effective log
drift, the horizon-average correction, and the arithmetic in words.

The primer `docs/QUANTGEN_Models_Primer.pdf` explains every model, the
maximum-likelihood fit, each guardrail, and the drift study.

### Portfolio — Markowitz, risk parity, the frontier

Aligns histories on shared dates, then solves all four objectives — max
Sharpe, min volatility, risk parity, equal weight — so the frontier chart can
mark them against each other and against a 1,500-portfolio random cloud, with
weight and risk contribution per asset side by side.

### Signals — the technical read, and the backtest that keeps it honest

A weighted composite of six components with each component's reason and its
dissent visible, above a costed backtest of the same idea against buy-and-hold.
Signals are computed on close *t* and earn returns from *t+1*.

---

## The expansion surfaces (version 3)

Design and build record: `docs/ASSET_EXPANSION_SPEC.md`. Research:
`reports/QUANTGEN asset coverage expansion.md` and
`research_notes/QUANTGEN asset coverage expansion/`. Plain-language companion:
`docs/QUANTGEN_Expansion_Primer.pdf` (built by
`docs/build_expansion_primer.py` from the study's cards, citing the operator's
own study materials).

### Derivatives — the KOSPI 200 surface before any strategy

The nearest expiry quoted series by series from the keyless KRX master (the
board endpoint stops at its top 100 strikes): futures basis and cost-of-carry
fair value against KIS's theoretical price, the parity-implied forward,
Black-76 inversion of every two-sided quote against KIS's implied vol, put-call
parity residuals, butterfly and vertical arbitrage counts, a raw SVI smile with
the Gatheral–Jacquier g(k) check, the Cboe model-free implied variance, the
Breeden–Litzenberger risk-neutral density and the empirical pricing kernel
against the Quant Lab's GARCH-t terminal density, the box-spread implied KRW
rate, and a delta-hedging P&L simulation (GBM or GARCH-t) that reports the
gamma-weighted break-even volatility. A board captured with the market closed
is last prints struck at different moments: the page says so in red, measures
time to expiry from the last session, and marks every figure indicative.

### ETF — NAV, basket, drag, sleeves

KIS NAV and premium with its ADF and half-life, the constituent basket,
leveraged-fund drag from the Avellaneda–Zhang identity at the last quarter's
realised variance (the study's better reference) and at the GARCH-t variance
term structure, and the trend-switch and vol-target sleeve rules on the fund's
own history — every one with the validation study's verdict beside it.

### Crypto — read-only, keyless

Kimchi premium (Upbit KRW-BTC against the world price at the FRED fixing) with
ADF, half-life and a predictive test; perpetual funding carry with deciles and
a bootstrap; a six-component regime score whose missing components redistribute
their weight; GARCH(1,1)-t on bitcoin with its out-of-sample verdict and the
stationarity share; the ETH/BTC unit-root test; the weekday table; optional
Upbit balances with an asset-inquiry-only key. Refused by construction: any
order, withdrawal, transfer or deposit-address path on any venue; private keys,
seed phrases and wallet secrets; transaction signing; accounts on unregistered
foreign exchanges; the ccxt / web3 / pyupbit dependencies; tax computation.

### Strategy Lab — the scorecard and the families

Every model card of the study (`docs/asset_expansion/cards/*.json`) with its
plain-language test lines, decision and reason; and every strategy family
(trend switch, vol target, cross-sectional momentum, TSMOM, pairs, crypto
trend, risk parity) runnable on any symbols and source through the same gate.

### The gate

`core/quant/validate.py`, pre-registered and changed nowhere else: purged
walk-forward (IS 756 / OOS 126 sessions, embargo = holding period) on a T × G
P&L matrix; annualised Sharpe with Lo's standard error and a studentised
circular block-bootstrap 90 % interval; the deflated Sharpe ratio for every
trial ever run; PBO by CSCV read together with the probability that the
in-sample winner loses out of sample (PBO is 0.5 by construction on a flat
plateau); OOS/IS; a paired block-bootstrap test against the benchmark when the
claim is "beats"; positive-year share; survival at 2× pre-registered costs
(KRX ETF 3 bp, KRX stock 35 bp, US via KIS 50 bp, crypto 10 bp, futures 5 bp,
FX 10 bp per side); the parameter plateau and edge; a regime split; the
McLean–Pontiff haircut. Distributional models: Kupiec, Christoffersen, the
Basel traffic light, 90 % coverage, PIT (KS, χ², Berkowitz, DGT correlograms),
QLIKE against EWMA with Diebold–Mariano. Decisions PASS / REVISE / REJECT /
INSUFFICIENT_DATA, each line stating the number, the threshold and the sample.

### What the study decided

`docs/asset_expansion_study.py` runs 34 cards on real history and writes
`docs/asset_expansion/results.md`, `results.csv` (md5-stamped on every card)
and `cards/*.json`; `--only id1,id2` re-scores a subset and merges. The
substantive findings, each on its card with the numbers:

* **Offered as a signal**: the crypto trend rule on KRW-BTC (PASS: every
  criterion, beats buy-and-hold at p 0.02, survives 2× costs). The same rule
  on BTC-USD passes every criterion but sits on a grid edge (REVISE).
* **Offered as monitors**: funding carry (the BIS sign confirmed), the weekday
  table (no return effect, a weekend-volume cost input), the futures basis
  (reconciles with KIS's theoretical price within the dividend band), the
  kimchi premium, the PCA fly, the LETF drag at realised variance.
* **Rejected, and shown as rejected**: the ETF trend switch (protects the
  drawdown, does not beat buy-and-hold on Sharpe), capped vol targeting (the
  Cederburg real-time result), unlevered risk parity, sector momentum after
  50 bp, futures TSMOM on Yahoo continuous contracts, the pairs trades (the
  gold pair and Hyundai/Kia fail the deflated Sharpe; the Samsung
  common/preferred tilt does not beat holding both legs; the KODEX/TIGER
  tracker pair is REVISE because its 1-session half-life is bid-ask bounce
  that loses at 2× costs), the VIX roll-down, G10 FX momentum, dollar carry,
  the Diebold–Li forecast (0/5 maturities beat the random walk), the ETH/BTC
  pair.
* **Volatility fans**: the app's symmetric GARCH-t under-covers the 5 % left
  tail on SPY and KODEX 200 (6.6–6.8 % of days); a GJR leverage term does not
  change the breach count, a Hansen skewed-t innovation does (REVISE on the
  PIT test only, on SPY). Bitcoin's variance is near-integrated in most
  windows, so every bitcoin fan reads REVISE. The Quant Lab shows the measured
  breach rate and the skewed-t verdict beside every fit.

Two harness defects found by the second run and fixed before the third are
recorded in the spec: an "edge" was counted on two-value grid axes, and PBO
alone rejected flat plateaus.

## AI-generated analysis, two layers

Every result ends in an **Analysis** card:

1. **Local narrative** (always) — a deterministic written read of the computed
   numbers. No network, no key, and it never invents a number that wasn't
   computed upstream. The FICC narratives speak the desk's language: the curve
   regime in basis points, the swaption premium in bp of notional, the carry
   long and its funder with carry-to-vol.
2. **Deep analysis** (with `ANTHROPIC_API_KEY`) — the same structured payload
   goes to the Claude API for a generative read in the voice of a sell-side
   rates/FX strategist: cross-metric tensions, sensitivity, the trade
   expression, what would invalidate the view. The Macro page's two report
   buttons append a report format (headline, rates, FX, positioning with
   levels) to whatever question you attach.

Model defaults to `claude-sonnet-5`; override with `QUANTGEN_AI_MODEL`.

## Data sources

| Source | Serves | Needs |
|---|---|---|
| **FRED** | Treasury par curve (1m–30y), SOFR, Fed funds, ECB deposit rate, SONIA, OECD short rates, real yields, breakevens, IG/HY OAS, dollar index, FX fixings, VIX, WTI | nothing — keyless |
| **Yahoo Finance** | FX spot histories (EURUSD, USDJPY, USDKRW, …), 10y note future, gold | nothing — keyless |
| FMP | US (and plan-permitting international) daily EOD, closes adjusted for splits **and dividends** (`/historical-price-eod/dividend-adjusted`) | `FMP_API_KEY` |
| KIS | KRX daily OHLCV (6-digit codes route here automatically); **version 3**: ETF NAV / premium / constituents, KOSPI 200 futures and the option chain, KTB and USD futures (market `CF`), KRW benchmark yields (`Y0101`…`Y0117`, CD 91d), US yields, USD/KRW fixing, overseas prices (`NAS:AAPL`), exchange-traded KTBs, investor flows and short sales — all quotation-only, one stock-account key | `KIS_APP_KEY` + `KIS_APP_SECRET` |
| **Upbit / Binance / CoinGecko** | KRW-BTC daily candles since 2017, USDT spot klines, perpetual funding history, premium index, open interest, the top-N list; `KRW-BTC` / `BTCUSDT` route here automatically | nothing — keyless (`UPBIT_ACCESS_KEY` / `UPBIT_SECRET_KEY`, asset-inquiry scope, only for the balance tile) |
| Synthetic | Seeded per-symbol series, curves and rates | nothing |

FICC fetches are cached on disk (`~/.nextgen/ficc_cache`, six hours by default)
so a page refresh does not re-download two years of the curve. The same cache
now holds every price history that goes through `load_history` (FMP, KIS,
Yahoo, Upbit, Binance), so re-running Quant Lab, Signals, Portfolio or Strategy
Lab does not spend provider quota on unchanged bars; a series served from disk
says `cached <time>` in its note, which each page shows beside the source. A
series fetched while its market may be trading ends in a running price, so it
is kept for ten minutes only; fetched with the market closed it is kept for the
full TTL. `NEXTGEN_FICC_CACHE_TTL=0` switches the cache off, and deleting the
`HIST_*.json` files forces a refetch.

Price adjustment, by provider: Yahoo and FMP closes are adjusted for splits and
dividends (total return). KIS 수정주가 is adjusted for splits and rights only —
cash dividends are not reinvested — so a 6-digit KRX code is a price-return
series; ask for `005930.KS` with source `yfinance` when you need total return.
Portfolio and Strategy Lab warn when one panel mixes the two conventions.

The history and analysis clients share one HTTP session (`data/net.py`) that
retries a failed GET twice (connection errors and 502/503/504 only; never a 429
or 500, and never a POST that reached the server). KIS calls are also paced to
about eight a second, because KIS rejects a burst with its per-second-limit
error. The engine's quote path makes one attempt per pass instead: there,
a quote that goes missing for a reason that can clear by itself is skipped for
up to `NEXTGEN_NO_DATA_GRACE` passes (default 3), the Execution page names the
symbol while it lasts, and only then does the engine halt. A plan refusal,
missing key or stale quote still halts at once, and a halt still needs a manual
acknowledge and re-arm. With zero keys
and no network, every page still works on synthetic data — and says so in a
loud banner, because a swaption priced off a simulated curve is a toy and must
look like one. An explicitly chosen provider that fails **raises**; only
`auto` falls back, and only with the provider named in the note.

## gs_quant integration

Two tiers, reported honestly on Settings:

* **Offline** (active whenever `gs-quant` is installed): realized volatility
  and max drawdown in the equity risk module route through `gs_quant.timeseries`.
* **Session** (with `GS_CLIENT_ID`/`GS_CLIENT_SECRET`): opens a Marquee
  `GsSession` for instrument resolution and pricing. gs_quant's rates and FX
  functions (swap rates, swaption vols, FX smiles) all need this session, which
  is why the FICC core prices locally.

## Everything inherited from NEXTGEN

Execution, Rules, Workflows, Skills, KRX, Runs, and Settings are the NEXTGEN
surfaces, unchanged: the DISARMED→ARMED→HALTED engine, frozen rules with
edit-revokes-confirmation, the simulated order book (there is still **no
broker order path** in this repository), the 72-skill cockpit, and the
KIS/OpenDART/KRX data layer.

## Setup

1. Python 3.10+
2. `pip install -r requirements.txt`
3. `cp .env.example .env` and fill in what you have (everything is optional —
   the FICC pages need nothing)
4. `python main.py`

## Verification

```bash
python tests/run_all.py
```

**229 checks**: the 125 inherited NEXTGEN suites (engine, cockpit, Flet API
guard), **48 equity quant checks** (the original Monte Carlo, optimizer,
signal and backtest invariants, plus GARCH parameter recovery on a simulated
series, unit-variance t shocks, guardrail flags, likelihood ordering against
GBM and normal-GARCH, forecast convergence, the drift-mode ordering and
zero-drift centring checks, the bounded-innovation and martingale checks of
every model under the rate drifts, the LR null size, the 95 % interval
coverage of α, β and ν on 50 simulated fits, and the bound chips on a ν = 2.7
fit) and **56 FICC checks** — bootstrap round-trips
its par inputs, discount factors are monotone, Nelson-Siegel fits tight, PCA
explains level first, bond duration matches the numeric derivative and KRD
sums to DV01, carry and roll are a holding-period P&L, scenarios show
convexity, a par swap has zero PV and payer DV01 is positive, swaption
put-call parity, Black ↔ Bachelier implied vols round-trip, a cap is its
caplets and cap minus floor is the swap, Garman-Kohlhagen parity and delta
bounds, strike ↔ delta round-trips, the smile follows the risk reversal, SABR
reproduces its quotes, CIP forwards have zero basis, the carry backtest is
sane, lag-aware and costs only hurt, CIR paths stay non-negative, Hull-White
matches the curve at t=0, structured products price below issue with
positive participation, and every narrative states its numbers. The suite is
hermetic: it patches the network touchpoints to raise, so it can never spend
a quota or call the Claude API, and it proves that `auto` degrades to a
labeled synthetic series when the provider is gone.

Version 3 adds the **expansion group** (`tests/expansion_acceptance.py`): a
fake KIS transport for every new asset domain (paging, the `CF` market, the
option chain from the master), a fake crypto transport (Upbit / Binance
candles, funding, the JWT), the gate's own checks (a planted edge is found and
passes, pure noise is rejected, the deflated Sharpe orders them, the
distribution loop calibrates a true model and fails a wrong one), the
t+1 causality of every strategy family, and the self-check of each new module
(strategies, validate, equity_deriv, curve_models, fx_styles, vol_products,
crypto analytics, GJR / skewed-t). The whole suite is **245 checks**.

Results land in `qa/acceptance_results.json`.

## Charts

Flet 0.85 ships no chart controls, so every chart — the equity six and the
FICC sixteen (curve with par/zero/forward and the NS fit, curve history, PCA
loadings, key-rate DV01 bars, scenario P&L, price/yield with the duration
tangent, smile with market points, payoff diagrams, rate fans, horizon P&L
histograms, spot with the forward curve, carry equity, carry bars, caplets,
macro z-scores) — renders through matplotlib (Agg) into base64 data-URI
images, painted with the app palette.

## Regulatory note

QUANTGEN is built for the operator's personal use only. It intentionally does
not implement the recommendation-abstinence constraints of the NEXTGEN client
build, and it is not designed to satisfy Korean FSCMA or US SEC requirements
for commercial financial software. Do not distribute it as a product.
