"""NEXTGEN verification suite."""
