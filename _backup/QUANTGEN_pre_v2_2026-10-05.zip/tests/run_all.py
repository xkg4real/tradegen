"""Run the acceptance suite and write a machine-readable result file.

Two fixes over the previous runner, both of which made it unusable on this
machine:

  * stdout is forced to UTF-8. The default on Windows Korean locale is cp949,
    which cannot encode the em dash or the Hangul in provider labels, so the
    runner died with `UnicodeEncodeError` before printing its summary.
  * the output directory is created before writing. The old runner wrote to
    `qa/acceptance_results.json` without `mkdir`, so a clean checkout ended in
    `FileNotFoundError` after every test had already run.
"""
from __future__ import annotations

import json
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

from tests.acceptance import tests as cockpit_tests        # noqa: E402
from tests.engine_acceptance import tests as engine_tests  # noqa: E402
from tests.flet_api_guard import tests as ui_tests          # noqa: E402
from tests.quant_acceptance import tests as quant_tests     # noqa: E402
from tests.ficc_acceptance import tests as ficc_tests       # noqa: E402
from tests.expansion_acceptance import tests as expansion_tests   # noqa: E402


def tests():
    return ([(f"cockpit/{n}", f) for n, f in cockpit_tests()] +
            [(f"engine/{n}", f) for n, f in engine_tests()] +
            [(f"ui/{n}", f) for n, f in ui_tests()] +
            [(f"quant/{n}", f) for n, f in quant_tests()] +
            [(f"ficc/{n}", f) for n, f in ficc_tests()] +
            [(f"expansion/{n}", f) for n, f in expansion_tests()])


results = []
for name, fn in tests():
    started = time.perf_counter()
    try:
        fn()
        status, detail = "PASS", ""
    except Exception as exc:
        status, detail = "FAIL", f"{type(exc).__name__}: {exc}"
        traceback.print_exc()
    results.append({
        "test": name,
        "status": status,
        "seconds": round(time.perf_counter() - started, 4),
        "detail": detail,
    })
    print(f"{status} {name} {detail}".rstrip())

out = ROOT / "qa" / "acceptance_results.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")

passed = sum(r["status"] == "PASS" for r in results)
print(f"\n{passed}/{len(results)} passed; {out}")
raise SystemExit(0 if passed == len(results) else 1)
